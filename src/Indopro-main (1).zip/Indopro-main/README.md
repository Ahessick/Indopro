# DesertAdventure
* OOP graphical game with keyboard and mouse listeners, similar to Adventure Island or Super Mario. Uses the proccesing application

## UI and Logic Planning
<img src="https://github.com/Ahessick/Indopro/blob/main/images/DesertAdventure1.jpg?raw=true">

## Mockup/Images
<img src="https://github.com/Ahessick/Indopro/blob/main/images/Cactus.png?raw=true">
<img src="https://github.com/Ahessick/Indopro/blob/main/images/startscreen.png?raw=true">



















